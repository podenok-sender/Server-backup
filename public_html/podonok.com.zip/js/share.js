


<!-- Put this script tag to the place, where the Share button will be -->
function share_VK(){
	document.write(VK.Share.button({url: "https://bsuir.lab.bhuser.ru/mobile.php"},{type: "round", text: "Поделиться"}));
}